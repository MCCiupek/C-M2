// Files.cpp�: d�finit le point d'entr�e pour l'application console.
//

#include "stdafx.h"

#include <fstream>   // pour les fichiers
#include <iostream>  // pour l'affichage dans la console
#include <string>    // pour les cha�nes de caract�res

using namespace std;

int main()
{

	ifstream fin;
	ofstream fout;
	string line;

	fin.open("myFile.txt");
	fout.open("myOutput.txt");
	
	while( getline(fin, line) ) {
		cout << line << endl;
		fout << line << endl;
	}

	fin.close();
	fout.close();

	system("PAUSE");

    return 0;
}


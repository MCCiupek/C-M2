double Pricer::N( double x )
{
	double a1 =  0.319381530;
	double a2 = -0.356563782;
	double a3 =  1.781477937;
	double a4 = -1.821255978;
	double a5 =  1.330274429;
	double k;
		
	if( x >= 0.0 )
	{
		k = 1/(1+0.2316419*x);
		return ( 1-NP(x) * ( (a1*k) + (a2*k*k) + (a3*k*k*k) + (a4*k*k*k*k) + (a5*k*k*k*k*k) ) );
	}
	else
	{
		return (1-N(-x));
	}
}

double Pricer::NP( double x )
{
	return (1.0/sqrt(2.0 * 3.1415) * exp(-x*x*0.5));
}
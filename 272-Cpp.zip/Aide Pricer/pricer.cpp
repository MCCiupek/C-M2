
#include <iostream>
#include <cmath>
#include <fstream>

using namespace std;

#include "ClassPricer"
#include "MathFunctions"
// dans MathFunctions :
// double NP( double x );
// double  N( double x );

int main( int argc, char ** argv )
{
	// param�tres du pricer
	// Am�lioration : lire depuis un fichier...
	// ifstream fin;
	// string line;
	// fin.open("inputFile.txt");
	// if (fin.is_open()) {
	// 	while ( getline (fin,line) ) {
	//		cout << line << '\n';
	//	}
	// }
	// fin.close();
	double S   = 50;   // price of stock or underlying security
	double K   = 40;   // strike price
	double r   = 0.03; // interest rate
	double q   = 0.0;  // dividend yield
	double T   = 0.5;  // Remaining life
	double sig = 0.3;  // volatility
	
	ClassPricer monPricer( S, K, r, q, T, sig);

	ofstream fout;
	
	cout << "Call Price: " << monPricer.euroCall() << endl;
	cout << "Put  Price: " << monPricer.euroPut()  << endl;

	monPricer.displayGreeks();
	/* Equivalent aux ligne ci dessous :
	cout << "Call Delta: " << monPricer.euroCallDelta() << endl;
	cout << "Put  Delta: " << monPricer.euroPutDelta () << endl;
	cout << "Call Theta: " << monPricer.euroCallTheta() << endl;
	cout << "Put  Theta: " << monPricer.euroPutTheta () << endl;
	cout << "Gamma     : " << monPricer.euroGamma    () << endl;
	cout << "Vega      : " << monPricer.euroVega     () << endl;
	cout << "Call Rho  : " << monPricer.euroCallRho  () << endl;
	cout << "Put  Rho  : " << monPricer.euroPutRho   () << endl;
	
	cout << endl;
	cout << "Put Price from Put-Call Parity: " << monPricer.getPutFromCall() << endl;
	cout << "Put Price from Put-Call Parity: " << callPrice + K*exp(-r*T) - S*exp(-q*T) << endl;
	*/

	// Afficher dans un fichier de sortie :
	fout.open("MyFile.txt");
	fout << "[Parameters]:" << endl;
	fout << monPricer.strParameters() << endl << endl;
	fout << "[CallPut]:" << endl;
	fout << monPricer.euroCall() << endl << monPricer.euroPut() << endl << endl;
	fout << "[Greeks]:" << endl;
	// ToDo...

	fout.close();

	system("PAUSE");

	return 0;
}

